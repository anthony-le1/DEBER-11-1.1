package com.biblioteca.API.controller;

import com.biblioteca.API.model.Libro;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/libros")
public class LibroController {

    private List<Libro> libros = new ArrayList<>();

    @GetMapping
    public ResponseEntity<List<Libro>> obtenerLibros() {
        return ResponseEntity.ok(libros);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Libro> obtenerLibro(@PathVariable Long id) {
        for (Libro libro : libros) {
            if (libro.getId().equals(id)) {
                return ResponseEntity.ok(libro);
            }
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/buscar")
    public ResponseEntity<List<Libro>> buscarLibro(
            @RequestParam String autor,
            @RequestParam(required = false) Integer anio) {

        List<Libro> resultado = new ArrayList<>();

        for (Libro libro : libros) {
            if (libro.getAutor().equalsIgnoreCase(autor)) {
                if (anio == null || libro.getAnioPublicacion() == anio) {
                    resultado.add(libro);
                }
            }
        }
        return ResponseEntity.ok(resultado);
    }

    @PostMapping
    public ResponseEntity<Libro> crearLibro(@RequestBody Libro libro) {
        libros.add(libro);
        return ResponseEntity.status(HttpStatus.CREATED).body(libro);
    }
}

